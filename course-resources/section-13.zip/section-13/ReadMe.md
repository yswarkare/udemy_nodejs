Useful Resources & Links
Attached, you find the source code for this section.

When using my source code, make sure to run npm install in the extracted folder!

Useful resource:

Mongoose Official Docs: https://mongoosejs.com/docs/

Resources for this lecture
