# Useful Resources & Links

Attached, you find the source code for this section.

Useful resources:

Official Node.js Docs: https://nodejs.org/en/docs/guides/

Full Node.js Reference (for all core modules): https://nodejs.org/dist/latest/docs/api/

More about the Node.js Event Loop: https://nodejs.org/en/docs/guides/event-loop-timers-and-nexttick/

Blocking and Non-Blocking Code: https://nodejs.org/en/docs/guides/dont-block-the-event-loop/
